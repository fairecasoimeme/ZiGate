<?php
	define('COM', "/dev/ttyUSB0");
	$in = "/var/www/html/zigate/input";

?>